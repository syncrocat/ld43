cardsSet = {};

cardsSet.TestCard = function() {
    Card.call (
        this
    );



}